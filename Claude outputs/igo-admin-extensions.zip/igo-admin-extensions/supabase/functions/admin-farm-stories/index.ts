// admin-farm-stories
//
// CRUD + publish workflow for farm story content (phase21_admin_extensions.sql).
// Public site reads is_published = true rows directly via RLS; this
// function is the admin write path and the only way to see drafts.
import { corsHeaders, jsonResponse, errorResponse } from "../_shared/cors.ts";
import { requireAdmin, logAudit, handleAdminError } from "../_shared/admin.ts";

const PERMISSION = "farm_stories.manage";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const body = await req.json();
    const action = body.action as string;

    const { db, userId, roleName } = await requireAdmin(req, PERMISSION);

    switch (action) {
      case "list": {
        let query = db
          .from("farm_stories")
          .select("*, farmers ( name, farm_name )", { count: "exact" })
          .order("display_order")
          .order("created_at", { ascending: false });
        if (body.publishedOnly) query = query.eq("is_published", true);
        if (body.farmerId) query = query.eq("farmer_id", body.farmerId);
        const { data, error, count } = await query;
        if (error) return errorResponse(error.message, 500);
        return jsonResponse({ stories: data, total: count });
      }

      case "get": {
        if (!body.id) return errorResponse("id is required.");
        const { data, error } = await db.from("farm_stories").select("*, farmers ( name, farm_name )").eq("id", body.id).maybeSingle();
        if (error) return errorResponse(error.message, 500);
        if (!data) return errorResponse("Story not found.", 404);
        return jsonResponse({ story: data });
      }

      case "create": {
        if (!body.title || !body.body) return errorResponse("title and body are required.");
        const payload = {
          title: body.title,
          body: body.body,
          farmer_id: body.farmerId ?? null,
          cover_image_url: body.coverImageUrl ?? null,
          gallery_urls: body.galleryUrls ?? [],
          is_published: body.isPublished ?? false,
          published_at: body.isPublished ? new Date().toISOString() : null,
          display_order: body.displayOrder ?? 0,
        };
        const { data, error } = await db.from("farm_stories").insert(payload).select().single();
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "farm_story.created", entityType: "farm_story", entityId: data.id });
        return jsonResponse({ story: data });
      }

      case "update": {
        if (!body.id) return errorResponse("id is required.");
        const payload: Record<string, unknown> = {};
        const fieldMap: Record<string, string> = {
          title: "title", body: "body", farmerId: "farmer_id", coverImageUrl: "cover_image_url",
          galleryUrls: "gallery_urls", displayOrder: "display_order",
        };
        for (const [key, column] of Object.entries(fieldMap)) if (body[key] !== undefined) payload[column] = body[key];
        if (Object.keys(payload).length === 0) return errorResponse("No fields to update.");

        const { data, error } = await db.from("farm_stories").update(payload).eq("id", body.id).select().single();
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "farm_story.updated", entityType: "farm_story", entityId: body.id, details: payload });
        return jsonResponse({ story: data });
      }

      case "setPublished": {
        if (!body.id || body.isPublished === undefined) return errorResponse("id and isPublished are required.");
        const payload: Record<string, unknown> = {
          is_published: body.isPublished,
          published_at: body.isPublished ? new Date().toISOString() : null,
        };
        const { data, error } = await db.from("farm_stories").update(payload).eq("id", body.id).select().single();
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: body.isPublished ? "farm_story.published" : "farm_story.unpublished", entityType: "farm_story", entityId: body.id });
        return jsonResponse({ story: data });
      }

      case "delete": {
        if (!body.id) return errorResponse("id is required.");
        const { error } = await db.from("farm_stories").delete().eq("id", body.id);
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "farm_story.deleted", entityType: "farm_story", entityId: body.id });
        return jsonResponse({ deleted: true });
      }

      default:
        return errorResponse(`Unknown action: ${action}`);
    }
  } catch (e) {
    return handleAdminError(e);
  }
});
