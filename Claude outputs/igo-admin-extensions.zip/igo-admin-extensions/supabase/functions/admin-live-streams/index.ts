// admin-live-streams
//
// CRUD + status workflow for live-shopping streams (phase21_admin_extensions.sql).
// Streams embed an external URL (YouTube/Instagram/Facebook/custom) rather
// than hosting video — this function never touches video infrastructure,
// only the schedule/metadata row.
import { corsHeaders, jsonResponse, errorResponse } from "../_shared/cors.ts";
import { requireAdmin, logAudit, handleAdminError } from "../_shared/admin.ts";

const PERMISSION = "live_streams.manage";
const VALID_STATUSES = ["scheduled", "live", "ended", "cancelled"];
const VALID_PLATFORMS = ["youtube", "instagram", "facebook", "custom"];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const body = await req.json();
    const action = body.action as string;

    const { db, userId, roleName } = await requireAdmin(req, PERMISSION);

    switch (action) {
      case "list": {
        let query = db.from("live_streams").select("*", { count: "exact" }).order("scheduled_at", { ascending: false, nullsFirst: false });
        if (body.status) query = query.eq("status", body.status);
        const { data, error, count } = await query;
        if (error) return errorResponse(error.message, 500);
        return jsonResponse({ streams: data, total: count });
      }

      case "get": {
        if (!body.id) return errorResponse("id is required.");
        const { data, error } = await db.from("live_streams").select("*").eq("id", body.id).maybeSingle();
        if (error) return errorResponse(error.message, 500);
        if (!data) return errorResponse("Stream not found.", 404);
        return jsonResponse({ stream: data });
      }

      case "create": {
        if (!body.title || !body.streamUrl) return errorResponse("title and streamUrl are required.");
        if (body.platform && !VALID_PLATFORMS.includes(body.platform)) return errorResponse(`platform must be one of: ${VALID_PLATFORMS.join(", ")}`);
        const payload = {
          title: body.title,
          description: body.description ?? null,
          platform: body.platform ?? "youtube",
          stream_url: body.streamUrl,
          thumbnail_url: body.thumbnailUrl ?? null,
          scheduled_at: body.scheduledAt ?? null,
          featured_product_ids: body.featuredProductIds ?? [],
          created_by: userId,
        };
        const { data, error } = await db.from("live_streams").insert(payload).select().single();
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "live_stream.created", entityType: "live_stream", entityId: data.id });
        return jsonResponse({ stream: data });
      }

      case "update": {
        if (!body.id) return errorResponse("id is required.");
        const payload: Record<string, unknown> = {};
        const fieldMap: Record<string, string> = {
          title: "title", description: "description", platform: "platform", streamUrl: "stream_url",
          thumbnailUrl: "thumbnail_url", scheduledAt: "scheduled_at", featuredProductIds: "featured_product_ids",
        };
        for (const [key, column] of Object.entries(fieldMap)) if (body[key] !== undefined) payload[column] = body[key];
        if (Object.keys(payload).length === 0) return errorResponse("No fields to update.");

        const { data, error } = await db.from("live_streams").update(payload).eq("id", body.id).select().single();
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "live_stream.updated", entityType: "live_stream", entityId: body.id, details: payload });
        return jsonResponse({ stream: data });
      }

      case "setStatus": {
        if (!body.id || !body.status) return errorResponse("id and status are required.");
        if (!VALID_STATUSES.includes(body.status)) return errorResponse(`status must be one of: ${VALID_STATUSES.join(", ")}`);

        const payload: Record<string, unknown> = { status: body.status };
        if (body.status === "live") payload.started_at = new Date().toISOString();
        if (body.status === "ended") payload.ended_at = new Date().toISOString();

        const { data, error } = await db.from("live_streams").update(payload).eq("id", body.id).select().single();
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "live_stream.status_changed", entityType: "live_stream", entityId: body.id, details: { status: body.status } });
        return jsonResponse({ stream: data });
      }

      case "delete": {
        if (!body.id) return errorResponse("id is required.");
        const { error } = await db.from("live_streams").delete().eq("id", body.id);
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "live_stream.deleted", entityType: "live_stream", entityId: body.id });
        return jsonResponse({ deleted: true });
      }

      default:
        return errorResponse(`Unknown action: ${action}`);
    }
  } catch (e) {
    return handleAdminError(e);
  }
});
