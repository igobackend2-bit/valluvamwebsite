// admin-account-requests
//
// Admin queue for customer-initiated account requests (deletion, data
// export, wholesale upgrade, reactivation, email change). Customers create
// their own row directly via the account_requests RLS insert policy
// (phase21_admin_extensions.sql) — this function is only for the admin
// side: listing, viewing, and resolving them.
import { corsHeaders, jsonResponse, errorResponse } from "../_shared/cors.ts";
import { requireAdmin, logAudit, handleAdminError } from "../_shared/admin.ts";

const PERMISSION = "account_requests.manage";
const VALID_STATUSES = ["pending", "approved", "rejected", "completed"];
const VALID_TYPES = ["account_deletion", "data_export", "wholesale_upgrade", "reactivation", "email_change", "other"];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const body = await req.json();
    const action = body.action as string;

    const { db, userId, roleName } = await requireAdmin(req, PERMISSION);

    switch (action) {
      case "list": {
        let query = db
          .from("account_requests")
          .select("*, profiles ( full_name, email )", { count: "exact" })
          .order("created_at", { ascending: false });
        if (body.status) query = query.eq("status", body.status);
        if (body.requestType) query = query.eq("request_type", body.requestType);
        const limit = Math.min(Number(body.limit) || 50, 200);
        const offset = Number(body.offset) || 0;
        const { data, error, count } = await query.range(offset, offset + limit - 1);
        if (error) return errorResponse(error.message, 500);
        return jsonResponse({ requests: data, total: count });
      }

      case "get": {
        if (!body.id) return errorResponse("id is required.");
        const { data, error } = await db
          .from("account_requests")
          .select("*, profiles ( full_name, email, phone )")
          .eq("id", body.id)
          .maybeSingle();
        if (error) return errorResponse(error.message, 500);
        if (!data) return errorResponse("Request not found.", 404);
        return jsonResponse({ request: data });
      }

      case "resolve": {
        if (!body.id || !body.status) return errorResponse("id and status are required.");
        if (!VALID_STATUSES.includes(body.status)) return errorResponse(`status must be one of: ${VALID_STATUSES.join(", ")}`);
        if (body.status === "pending") return errorResponse("Use 'approved', 'rejected' or 'completed' to resolve a request.");

        const { data, error } = await db
          .from("account_requests")
          .update({
            status: body.status,
            admin_notes: body.adminNotes ?? null,
            resolved_by: userId,
            resolved_at: new Date().toISOString(),
          })
          .eq("id", body.id)
          .select()
          .single();
        if (error) return errorResponse(error.message, 500);

        await logAudit(db, {
          adminUserId: userId,
          role: roleName,
          action: "account_request.resolved",
          entityType: "account_request",
          entityId: body.id,
          details: { status: body.status },
        });
        return jsonResponse({ request: data });
      }

      case "create": {
        // Lets an admin log a request made offline (phone/email) on a
        // customer's behalf — most requests arrive via the customer's own
        // insert, this is the exception path.
        if (!body.userId || !body.requestType) return errorResponse("userId and requestType are required.");
        if (!VALID_TYPES.includes(body.requestType)) return errorResponse(`requestType must be one of: ${VALID_TYPES.join(", ")}`);

        const { data, error } = await db
          .from("account_requests")
          .insert({ user_id: body.userId, request_type: body.requestType, details: body.details ?? {} })
          .select()
          .single();
        if (error) return errorResponse(error.message, 500);

        await logAudit(db, { adminUserId: userId, role: roleName, action: "account_request.created", entityType: "account_request", entityId: data.id });
        return jsonResponse({ request: data });
      }

      default:
        return errorResponse(`Unknown action: ${action}`);
    }
  } catch (e) {
    return handleAdminError(e);
  }
});
