// admin-farmers
//
// CRUD for the farmer/sourcing-partner directory (phase21_admin_extensions.sql).
// Public site reads active farmers directly via RLS; this function is the
// admin write path (and the only way to see inactive/archived farmers).
import { corsHeaders, jsonResponse, errorResponse } from "../_shared/cors.ts";
import { requireAdmin, logAudit, handleAdminError } from "../_shared/admin.ts";

const PERMISSION = "farmers.manage";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const body = await req.json();
    const action = body.action as string;

    const { db, userId, roleName } = await requireAdmin(req, PERMISSION);

    switch (action) {
      case "list": {
        // Admin sees everything, active or not — public RLS only exposes
        // is_active = true, this function bypasses that via the
        // service-role client on purpose.
        let query = db.from("farmers").select("*", { count: "exact" }).order("display_order").order("name");
        if (body.activeOnly) query = query.eq("is_active", true);
        const { data, error, count } = await query;
        if (error) return errorResponse(error.message, 500);
        return jsonResponse({ farmers: data, total: count });
      }

      case "get": {
        if (!body.id) return errorResponse("id is required.");
        const { data, error } = await db.from("farmers").select("*").eq("id", body.id).maybeSingle();
        if (error) return errorResponse(error.message, 500);
        if (!data) return errorResponse("Farmer not found.", 404);
        return jsonResponse({ farmer: data });
      }

      case "create": {
        if (!body.name) return errorResponse("name is required.");
        const payload = {
          name: body.name,
          farm_name: body.farmName ?? null,
          location: body.location ?? null,
          bio: body.bio ?? null,
          photo_url: body.photoUrl ?? null,
          years_farming: body.yearsFarming ?? null,
          certifications: body.certifications ?? [],
          is_active: body.isActive ?? true,
          display_order: body.displayOrder ?? 0,
        };
        const { data, error } = await db.from("farmers").insert(payload).select().single();
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "farmer.created", entityType: "farmer", entityId: data.id });
        return jsonResponse({ farmer: data });
      }

      case "update": {
        if (!body.id) return errorResponse("id is required.");
        const payload: Record<string, unknown> = {};
        const fieldMap: Record<string, string> = {
          name: "name", farmName: "farm_name", location: "location", bio: "bio",
          photoUrl: "photo_url", yearsFarming: "years_farming", certifications: "certifications",
          isActive: "is_active", displayOrder: "display_order",
        };
        for (const [key, column] of Object.entries(fieldMap)) if (body[key] !== undefined) payload[column] = body[key];
        if (Object.keys(payload).length === 0) return errorResponse("No fields to update.");

        const { data, error } = await db.from("farmers").update(payload).eq("id", body.id).select().single();
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "farmer.updated", entityType: "farmer", entityId: body.id, details: payload });
        return jsonResponse({ farmer: data });
      }

      case "delete": {
        if (!body.id) return errorResponse("id is required.");
        // Soft-delete by default (is_active = false) so farm_stories that
        // reference this farmer don't dangle in the UI; a hard delete is
        // opt-in via body.hard = true.
        if (body.hard) {
          const { error } = await db.from("farmers").delete().eq("id", body.id);
          if (error) return errorResponse(error.message, 500);
        } else {
          const { error } = await db.from("farmers").update({ is_active: false }).eq("id", body.id);
          if (error) return errorResponse(error.message, 500);
        }
        await logAudit(db, { adminUserId: userId, role: roleName, action: "farmer.deleted", entityType: "farmer", entityId: body.id, details: { hard: !!body.hard } });
        return jsonResponse({ deleted: true });
      }

      default:
        return errorResponse(`Unknown action: ${action}`);
    }
  } catch (e) {
    return handleAdminError(e);
  }
});
