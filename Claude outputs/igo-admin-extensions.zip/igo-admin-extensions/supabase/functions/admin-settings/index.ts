// admin-settings
//
// Generic key/value settings CRUD (phase21_admin_extensions.sql). Keys are
// free-form (store_name, support_email, business_hours, ...) — new
// settings don't need a schema change, just a new key.
import { corsHeaders, jsonResponse, errorResponse } from "../_shared/cors.ts";
import { requireAdmin, logAudit, handleAdminError } from "../_shared/admin.ts";

const PERMISSION = "settings.manage";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const body = await req.json();
    const action = body.action as string;

    const { db, userId, roleName } = await requireAdmin(req, PERMISSION);

    switch (action) {
      case "list": {
        const { data, error } = await db.from("admin_settings").select("*").order("key");
        if (error) return errorResponse(error.message, 500);
        return jsonResponse({ settings: data });
      }

      case "get": {
        if (!body.key) return errorResponse("key is required.");
        const { data, error } = await db.from("admin_settings").select("*").eq("key", body.key).maybeSingle();
        if (error) return errorResponse(error.message, 500);
        if (!data) return errorResponse("Setting not found.", 404);
        return jsonResponse({ setting: data });
      }

      case "upsert": {
        if (!body.key || body.value === undefined) return errorResponse("key and value are required.");
        const payload = {
          key: body.key,
          value: body.value,
          description: body.description ?? null,
          is_public: body.isPublic ?? false,
          updated_by: userId,
        };
        const { data, error } = await db.from("admin_settings").upsert(payload, { onConflict: "key" }).select().single();
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "setting.updated", entityType: "admin_setting", entityId: body.key, details: { value: body.value } });
        return jsonResponse({ setting: data });
      }

      case "delete": {
        if (!body.key) return errorResponse("key is required.");
        const { error } = await db.from("admin_settings").delete().eq("key", body.key);
        if (error) return errorResponse(error.message, 500);
        await logAudit(db, { adminUserId: userId, role: roleName, action: "setting.deleted", entityType: "admin_setting", entityId: body.key });
        return jsonResponse({ deleted: true });
      }

      default:
        return errorResponse(`Unknown action: ${action}`);
    }
  } catch (e) {
    return handleAdminError(e);
  }
});
