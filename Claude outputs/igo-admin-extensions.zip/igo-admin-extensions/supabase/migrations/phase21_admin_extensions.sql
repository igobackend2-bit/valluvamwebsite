-- ============================================================================
-- Phase 21 (Admin Extensions) migration
--
-- Adds the four admin modules that had no table, function or screen behind
-- them yet: Account Requests, Live Streams, Farm Stories, Farmers — plus a
-- small general-purpose admin_settings table for the "Settings" menu item.
--
-- Follows the exact conventions established in phase18_admin.sql:
--   - New tables are additive only; nothing existing is altered, dropped,
--     or renamed.
--   - Customer-facing content (live_streams, farmers, farm_stories) is
--     publicly readable when published/active, same pattern as
--     `categories` — write access is service-role only (admin Edge
--     Functions), never a client-side policy.
--   - account_requests follows the same "user owns their own row" shape as
--     `support_tickets`: a customer can create and read their own request;
--     only an admin (via the service-role client) can resolve it.
--   - admin_settings is service-role-write / selectively-public-read via an
--     `is_public` flag, same shape as the others.
--   - New permission codes are added to admin_permissions and granted to
--     super_admin (automatic — see admin_has_permission) and explicitly to
--     the 'admin' role, matching how phase18_admin.sql grants 'admin'
--     everything except roles.manage.
-- ============================================================================

-- ─── account_requests ───────────────────────────────────────────────────────
-- Customer-initiated requests that need an admin decision: account
-- deletion, data export, upgrade to a wholesale/bulk-pricing account,
-- reactivation of a disabled account, or an email change that needs
-- verification. Kept generic (request_type + a jsonb details payload)
-- rather than one table per request type, so new request types can be
-- added later without a schema change.
create table if not exists public.account_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  request_type text not null check (request_type in (
    'account_deletion', 'data_export', 'wholesale_upgrade',
    'reactivation', 'email_change', 'other'
  )),
  details jsonb not null default '{}'::jsonb,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected', 'completed')),
  admin_notes text,
  resolved_by uuid references auth.users (id),
  resolved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists account_requests_user_created_idx on public.account_requests (user_id, created_at desc);
create index if not exists account_requests_status_idx on public.account_requests (status, created_at desc);

alter table public.account_requests enable row level security;

drop policy if exists "Users can view their own account requests" on public.account_requests;
create policy "Users can view their own account requests"
  on public.account_requests for select
  using (auth.uid() = user_id);

drop policy if exists "Users can create their own account requests" on public.account_requests;
create policy "Users can create their own account requests"
  on public.account_requests for insert
  with check (auth.uid() = user_id);

-- No client-side update policy: only an admin (service-role, via the
-- admin-account-requests Edge Function) can change status/resolve a
-- request — matches the "requests" side of this feature being an admin
-- queue, not a self-service edit.

create or replace function public.set_account_requests_updated_at()
returns trigger as $$
begin
  new.updated_at := now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_account_requests_updated_at on public.account_requests;
create trigger trg_account_requests_updated_at
  before update on public.account_requests
  for each row execute function public.set_account_requests_updated_at();

-- ─── farmers ────────────────────────────────────────────────────────────────
-- The sourcing-partner directory shown on the public site (and managed in
-- admin) — who the produce/meat comes from.
create table if not exists public.farmers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  farm_name text,
  location text,
  bio text,
  photo_url text,
  years_farming int,
  certifications text[] not null default '{}',
  is_active boolean not null default true,
  display_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists farmers_active_order_idx on public.farmers (is_active, display_order);

alter table public.farmers enable row level security;

drop policy if exists "Active farmers are publicly readable" on public.farmers;
create policy "Active farmers are publicly readable"
  on public.farmers for select
  using (is_active = true);

create or replace function public.set_farmers_updated_at()
returns trigger as $$
begin
  new.updated_at := now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_farmers_updated_at on public.farmers;
create trigger trg_farmers_updated_at
  before update on public.farmers
  for each row execute function public.set_farmers_updated_at();

-- ─── farm_stories ───────────────────────────────────────────────────────────
-- Editorial content ("meet the farm") — optionally tied to a farmer row.
create table if not exists public.farm_stories (
  id uuid primary key default gen_random_uuid(),
  farmer_id uuid references public.farmers (id) on delete set null,
  title text not null,
  body text not null,
  cover_image_url text,
  gallery_urls text[] not null default '{}',
  is_published boolean not null default false,
  published_at timestamptz,
  display_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists farm_stories_published_order_idx on public.farm_stories (is_published, display_order);
create index if not exists farm_stories_farmer_idx on public.farm_stories (farmer_id);

alter table public.farm_stories enable row level security;

drop policy if exists "Published farm stories are publicly readable" on public.farm_stories;
create policy "Published farm stories are publicly readable"
  on public.farm_stories for select
  using (is_published = true);

create or replace function public.set_farm_stories_updated_at()
returns trigger as $$
begin
  new.updated_at := now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_farm_stories_updated_at on public.farm_stories;
create trigger trg_farm_stories_updated_at
  before update on public.farm_stories
  for each row execute function public.set_farm_stories_updated_at();

-- ─── live_streams ───────────────────────────────────────────────────────────
-- Live-shopping / cook-along sessions, linked to an external stream
-- (YouTube/Instagram/Facebook/custom embed) rather than hosting video
-- ourselves. featured_product_ids lets a stream deep-link to the products
-- being shown, without creating a new products<->streams join table.
create table if not exists public.live_streams (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  platform text not null default 'youtube' check (platform in ('youtube', 'instagram', 'facebook', 'custom')),
  stream_url text not null,
  thumbnail_url text,
  status text not null default 'scheduled' check (status in ('scheduled', 'live', 'ended', 'cancelled')),
  scheduled_at timestamptz,
  started_at timestamptz,
  ended_at timestamptz,
  featured_product_ids uuid[] not null default '{}',
  created_by uuid references auth.users (id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists live_streams_status_scheduled_idx on public.live_streams (status, scheduled_at);

alter table public.live_streams enable row level security;

drop policy if exists "Non-cancelled live streams are publicly readable" on public.live_streams;
create policy "Non-cancelled live streams are publicly readable"
  on public.live_streams for select
  using (status <> 'cancelled');

create or replace function public.set_live_streams_updated_at()
returns trigger as $$
begin
  new.updated_at := now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_live_streams_updated_at on public.live_streams;
create trigger trg_live_streams_updated_at
  before update on public.live_streams
  for each row execute function public.set_live_streams_updated_at();

-- ─── admin_settings ─────────────────────────────────────────────────────────
-- General key/value store for the "Settings" screen (store name, support
-- contact, business hours, social links, tax rate, etc.) so new settings
-- don't need a new column/migration each time. is_public controls whether
-- the public website may read a given key (e.g. business_hours) or whether
-- it's admin-only (e.g. an internal note).
create table if not exists public.admin_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  description text,
  is_public boolean not null default false,
  updated_by uuid references auth.users (id),
  updated_at timestamptz not null default now()
);

alter table public.admin_settings enable row level security;

drop policy if exists "Public settings are publicly readable" on public.admin_settings;
create policy "Public settings are publicly readable"
  on public.admin_settings for select
  using (is_public = true);

create or replace function public.set_admin_settings_updated_at()
returns trigger as $$
begin
  new.updated_at := now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_admin_settings_updated_at on public.admin_settings;
create trigger trg_admin_settings_updated_at
  before update on public.admin_settings
  for each row execute function public.set_admin_settings_updated_at();

insert into public.admin_settings (key, value, description, is_public) values
  ('store_name', '"IGO Protein Cuts"'::jsonb, 'Public store name', true),
  ('support_email', '"support@igoproteincuts.com"'::jsonb, 'Public support email — update to the real inbox', true),
  ('support_phone', '""'::jsonb, 'Public support phone number — fill in', true),
  ('business_hours', '{"mon_sat": "7:00 AM - 9:00 PM", "sun": "8:00 AM - 6:00 PM"}'::jsonb, 'Displayed business hours', true),
  ('order_cutoff_minutes', '30'::jsonb, 'Minutes of notice required before the next delivery slot', false)
on conflict (key) do nothing;

-- ─── Seed: new permissions ──────────────────────────────────────────────────
insert into public.admin_permissions (code, description) values
  ('account_requests.manage', 'View and resolve customer account requests'),
  ('live_streams.manage', 'Create/schedule/publish live shopping streams'),
  ('farmers.manage', 'Manage the farmer/sourcing-partner directory'),
  ('farm_stories.manage', 'Write and publish farm story content'),
  ('settings.manage', 'Edit store settings')
on conflict (code) do nothing;

-- ─── Grant new permissions to existing roles ───────────────────────────────
-- super_admin already gets every permission implicitly via
-- admin_has_permission's `r.name = 'super_admin'` clause — no row needed.
-- 'admin' previously got "everything except roles.manage" as a snapshot at
-- migration time, so newly-added codes need an explicit grant here.
insert into public.admin_role_permissions (role_id, permission_id)
select r.id, p.id from public.admin_roles r, public.admin_permissions p
where r.name = 'admin'
  and p.code in (
    'account_requests.manage', 'live_streams.manage',
    'farmers.manage', 'farm_stories.manage', 'settings.manage'
  )
on conflict do nothing;

insert into public.admin_role_permissions (role_id, permission_id)
select r.id, p.id from public.admin_roles r, public.admin_permissions p
where r.name = 'manager'
  and p.code in ('account_requests.manage', 'live_streams.manage', 'farmers.manage', 'farm_stories.manage')
on conflict do nothing;
